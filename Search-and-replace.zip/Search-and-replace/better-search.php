<?php
/**
Plugin Name: Search and Replace
Plugin URI: 
Description: Plugin to Search and replace
Version: 1.5
Author: Arpita
Author URI: 
License: 
*/

/** Step 2 (from text above). */
add_action( 'admin_menu', 'my_plugin_menu' );
function my_plugin_menu() {
   add_options_page( 'My Plugin Options', 'Search and Replace', 'manage_options', 'search-replace', 'my_plugin_options' );
}
function my_plugin_options() {
   if ( !current_user_can( 'manage_options' ) )  {
      wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
   }
    $content  = '';
   $content .= '<div class="wrap"><form id="searchForm" action="" method="post">';
   $content .='<label for="sea">Search for : <label>';
   $content .='<input type="text" name="searchField" required>';
   $content .='<input type="text" name="replaceField" required>';
   $content .='<input type="submit"  name="submit" class="submit button" value="Search">';
   $content .='</form></div>';
   echo  $content;

   include( plugin_dir_path( __FILE__ ) . 'inc/front-end-out.php');
   //include( plugin_dir_path( __FILE__ ) . 'inc/Primary_key.php');
   
}

include( plugin_dir_path( __FILE__ ) . 'inc/Primary_key.php');

























