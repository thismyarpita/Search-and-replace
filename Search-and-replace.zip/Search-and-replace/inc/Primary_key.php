<?php 
add_action('init', 'primary_key_vlaue');
function primary_key_vlaue(){
        global $wpdb;
       
        $key_val = "";
        $shippingMethods = array();

        $tables_data=$wpdb->get_results('SHOW TABLES', ARRAY_A );
        foreach ($tables_data as $key_val=>$table_value)
        {
	   foreach ($table_value as $table_value_display) 
	   {  
	           // print_r($table_value_display);
	         	$query = "SHOW KEYS  FROM {$table_value_display} WHERE Key_name = 'PRIMARY' ";
	         	// echo $query; 
	         	 $columns_name = $wpdb->get_results($query);
	         	
	         	 
	         	 foreach ($columns_name as $column_val)
			 {
				    $method = array();
				    $method[$table_value_display] = $column_val->Column_name;
				  
				    $shippingMethods[$key_val] = $method;
				    //print_r($shippingMethods);
			 }  	
	   }
	     
        }
     return $shippingMethods;    
}

