<?php 
/*print_r($wpdb->tables);*/
/*$mytables = $wpdb->get_results( 'SHOW TABLE STATUS', ARRAY_A );*/
if (isset($_POST['submit'])){
        $code_qr = $_POST["searchField"];
        $replaceCode = $_POST["replaceField"];
        global $wpdb;
        $primarykey_value = primary_key_vlaue();
       /* $replacequery = "";*/
        $mytables=$wpdb->get_results('SHOW TABLES', ARRAY_A );
       /* $countFavs = 0;*/
        $final_code ='';
        foreach ($mytables as $tkey=>$mytable)
        {
       /* if ($countFavs == 5) break;*/
         foreach ($mytable as $tdata) 
         {  
           /* table data*/
             $primarykey_data=$primarykey_value[$tkey][$tdata]; 
             $existing_columns = $wpdb->get_col("DESC {$tdata}");
             $query = "SELECT * FROM {$tdata} "; 
                // LOOP ALL COLUMNES
                 $innerCount = 0;
                 foreach ($existing_columns as $col) 
                 {       
                    if( $innerCount == 0 ){
                        $query .= " WHERE ";
                    }
                    if( $innerCount != 0 ){
                        $query .= " OR ";
                    }
                    $query .= " ".$col . " LIKE '%".$code_qr."%'";
                 $innerCount++;
                 }   
              /* print_r($query => ); */

             $result =$wpdb->get_results($query);
             $rowcounts = count($result);
             if( $rowcounts >0){
                echo "<p style='color:green'>Table'". $tdata."' Row value '".$rowcounts."'</p>";
                //print_r($result);
                 foreach ($result as  $result_val) 
                 { 

                  foreach ($result_val as $rrkey=>$result_val_da) {
                   //print_r($result_val_da);
                   if($code_qr == $result_val_da){
                    //print_r($result_val_da);
                     $replacequery ="UPDATE {$tdata} SET ". $rrkey . " = REPLACE(".$rrkey .", '". $result_val_da."', '".$replaceCode."')  WHERE  ".$primarykey_data ."  = ".$result_val->$primarykey_data;
                      $update_value = $wpdb->query($replacequery);
                     //var_dump($update_value);
                      
                     if ($update_value == true) {
                        
                        echo "<h4 styel='color:green'>New result is</h4><table><thead><tr><th>". $rrkey. "</th></tr></thead><tbody><tr><td>". $replaceCode .  "</td></tr></tbody></table><h4>updated successfully</h4>";
                      }
                   }

                  }
                 }
             }
             else
             {
                 echo "<p>Table'". $tdata."' Row value '".$rowcounts."'</p>";
             }                       
         } 
       /* $countFavs++;*/
        }
}









?>


<style type="text/css">
table {
    /* font-family: Arial, Helvetica, sans-serif; */
    /* border-collapse: collapse; */
    width: 100%;
    display: unset;
}
</style>